import random

def Random_Team_Func(N:int, teams:int, names:list):
    l = N
    emptyList = []
    last_teams = [ list(emptyList) for i in range(teams)]
    for i in range(N//teams):
        for j in range(teams):
            n = random.randint(0, 1000) % l
            print("pls", names[n] ,"go to", j, "team")
            last_teams[j].append(names[n])
            names.pop(n)
            l -= 1
            if (l == 1):
                last_teams[(j+1)%teams].append(names[0])
                print("pls", names[0], "go to", (j+1)%teams,"team.")
                break

    return last_teams
"""

    while 1:
        N = input("people number: ")
        if (N.isnumeric() and int(N) != 0):
            N = int(N)
            break
        else:
            print("input wrong type. Pls input again.")

    while 1:
        teams = input("teams number: ")
        if (teams.isnumeric() and int(teams) != 0):
            teams = int(teams)
            break
        else:
            print("input wrong type. Pls input again.")

    print("input people name or number ")

    for i in range(N):
        print(i+1, end = " ")
        name = input("th: ")
        names.append(name)
"""
    
    









